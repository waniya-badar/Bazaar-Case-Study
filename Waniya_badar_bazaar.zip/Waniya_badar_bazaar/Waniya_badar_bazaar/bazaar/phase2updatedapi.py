from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg2
from typing import List
from datetime import datetime

# FastAPI app
app = FastAPI()

# Helper function to get the PostgreSQL connection
def get_db_connection():
    conn = psycopg2.connect(
        dbname="bazaar_db", user="your_user", password="your_password", host="localhost"
    )
    return conn

# Pydantic Models
class Product(BaseModel):
    name: str
    price: float

class Store(BaseModel):
    name: str
    location: str

class StockMovement(BaseModel):
    store_id: int
    product_id: int
    action: str  # "stock-in", "sell", "remove"
    quantity: int

class StoreInventory(BaseModel):
    store_id: int
    product_id: int
    quantity: int

# API Endpoints

# 1. Add a store
@app.post("/stores/")
def add_store(store: Store):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO stores (name, location) VALUES (%s, %s)", (store.name, store.location))
    conn.commit()
    conn.close()
    return {"message": "Store added successfully"}

# 2. Add a product
@app.post("/products/")
def add_product(product: Product):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, price) VALUES (%s, %s)", (product.name, product.price))
    conn.commit()
    conn.close()
    return {"message": "Product added successfully"}

# 3. Add stock movement (stock-in, sell, remove)
@app.post("/stock_movements/")
def add_stock_movement(movement: StockMovement):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Insert into stock movements table
    cursor.execute(
        "INSERT INTO stock_movements (store_id, product_id, action, quantity) VALUES (%s, %s, %s, %s)",
        (movement.store_id, movement.product_id, movement.action, movement.quantity)
    )

    # Update store inventory based on action
    if movement.action == "stock-in":
        cursor.execute(
            "UPDATE store_inventory SET quantity = quantity + %s WHERE store_id = %s AND product_id = %s",
            (movement.quantity, movement.store_id, movement.product_id)
        )
    elif movement.action == "sell" or movement.action == "remove":
        cursor.execute(
            "UPDATE store_inventory SET quantity = quantity - %s WHERE store_id = %s AND product_id = %s",
            (movement.quantity, movement.store_id, movement.product_id)
        )

    conn.commit()
    conn.close()
    return {"message": "Stock movement recorded successfully"}

# 4. Get inventory for a store
@app.get("/inventory/{store_id}")
def get_inventory(store_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT p.name, si.quantity FROM store_inventory si INNER JOIN products p ON si.product_id = p.id WHERE si.store_id = %s",
        (store_id,)
    )
    inventory = cursor.fetchall()
    conn.close()
    return {"store_id": store_id, "inventory": [{"product_name": row[0], "quantity": row[1]} for row in inventory]}

# 5. Get stock movements for a store within a date range
@app.get("/stock_movements/{store_id}")
def get_stock_movements(store_id: int, start_date: str, end_date: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT p.name, sm.action, sm.quantity, sm.date FROM stock_movements sm INNER JOIN products p ON sm.product_id = p.id WHERE sm.store_id = %s AND sm.date BETWEEN %s AND %s",
        (store_id, start_date, end_date)
    )
    movements = cursor.fetchall()
    conn.close()
    return {"store_id": store_id, "movements": [{"product_name": row[0], "action": row[1], "quantity": row[2], "date": row[3]} for row in movements]}
