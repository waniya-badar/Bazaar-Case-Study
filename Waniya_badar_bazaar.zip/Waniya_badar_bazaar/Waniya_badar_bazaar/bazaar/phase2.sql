import sqlite3

def init_db():
    conn = sqlite3.connect("inventory_phase2.db")
    cursor = conn.cursor()

    # Create Stores table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stores (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL
        )
    ''')

    # Create Products table (central catalog)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL
        )
    ''')

    # Create Store-specific Stock table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS store_stock (
            id INTEGER PRIMARY KEY,
            store_id INTEGER,
            product_id INTEGER,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (store_id) REFERENCES stores (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')

    conn.commit()
    conn.close()

init_db()
