
Inventory Tracking System - Backend Service
Overview
This project aims to design a scalable and efficient Inventory Tracking System for a retail platform (Bazaar Technologies) to manage inventory movements across multiple stores. The solution will be built in phases, evolving from a single-store model to support multiple stores, suppliers, and audit capabilities.

Phases
Phase 1: Build a single-store model using local storage (SQLite).

Phase 2: Scale to 500+ stores with relational databases (PostgreSQL) and REST API.

Phase 3: Scale to thousands of stores with horizontal scalability, caching, asynchronous processing, API rate limiting, and audit logs.

Design Decisions
Asynchronous Processing: To handle high traffic without blocking, we utilize a message queue (RabbitMQ or Kafka) for background processing of stock movements.

Read/Write Separation: For better performance and scalability, we employ a master-slave database setup. Writes are directed to the master, while reads are handled by replicas.

Caching: Frequently accessed data (e.g., product details) is cached in Redis to reduce database load and improve response time.

API Rate Limiting: To prevent abuse, we implemented rate limiting using the slowapi library.

Audit Logs: Every stock movement is logged to an audit_logs table to ensure traceability and accountability.

Assumptions
The system should support thousands of stores with near real-time stock synchronization.

Users will interact with the system via REST APIs, and products are tracked across multiple stores.

Asynchronous updates ensure that the system doesn’t block during stock movements, and inventory sync happens in the background.

Security Considerations: API access will be protected using basic authentication, and the system will handle sensitive data securely.

API Design
POST /stock-movement: Logs a stock movement (e.g., product stock-in, sell, or removal).

GET /inventory/{store_id}: Retrieves the inventory data for a specific store.

GET /products: Fetches all available products from the catalog.

GET /audit-logs: Retrieves the audit logs of stock movements.

Evolution Rationale (v1 → v3)
Phase 1 (v1):
Focused on building a single-store model with local storage (SQLite).

No external dependencies like caching, rate limiting, or message queues were required.

Phase 2 (v2):
Transitioned to PostgreSQL for relational database support.

Introduced a REST API for handling stock movements, with filtering and basic authentication.

Supported 500+ stores and handled basic stock movement functionalities.

Phase 3 (v3):
The system was designed for scalability to handle thousands of stores and concurrent transactions.

Horizontal scalability was introduced with read/write separation and message queues for asynchronous processing.

Implemented caching to optimize performance and rate limiting to prevent abuse.

Audit logs were added to track every stock movement for transparency and debugging.

Conclusion
This system is designed to evolve as Bazaar grows, scaling efficiently to support thousands of stores and millions of transactions. Each phase builds on the previous one, ensuring that the system remains reliable, secure, and high-performing as the business expands.