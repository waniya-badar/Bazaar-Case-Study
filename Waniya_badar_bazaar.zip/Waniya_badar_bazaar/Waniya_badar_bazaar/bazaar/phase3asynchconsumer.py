import pika
import json

def handle_stock_movement(ch, method, properties, body):
    movement_data = json.loads(body)
    # Process the stock movement (update the database)
    # Example: update_inventory(movement_data)
    print("Stock movement processed:", movement_data)

# Set up the consumer to listen for stock movements
def consume_stock_movements():
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='stock_movements')

    channel.basic_consume(queue='stock_movements', on_message_callback=handle_stock_movement, auto_ack=True)

    print('Waiting for messages...')
    channel.start_consuming()

consume_stock_movements()
