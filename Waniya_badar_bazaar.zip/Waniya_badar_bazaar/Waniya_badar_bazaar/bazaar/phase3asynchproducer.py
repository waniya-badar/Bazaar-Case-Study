import pika
import json

def send_stock_movement_message(movement_data):
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='stock_movements')

    channel.basic_publish(
        exchange='',
        routing_key='stock_movements',
        body=json.dumps(movement_data)
    )
    connection.close()

movement_data = {
    'store_id': 1,
    'product_id': 2,
    'action': 'sell',
    'quantity': 5
}

send_stock_movement_message(movement_data)
