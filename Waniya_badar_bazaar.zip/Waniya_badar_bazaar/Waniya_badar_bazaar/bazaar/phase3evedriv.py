from kafka import KafkaConsumer
import json

consumer = KafkaConsumer(
    'stock-updates',
    bootstrap_servers=['localhost:9092'],
    group_id='stock-sync-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

for message in consumer:
    event_data = message.value
    # Process the stock update event (e.g., synchronize with other stores)
    print(f"Received event: {event_data}")
