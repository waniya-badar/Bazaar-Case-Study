import redis
import psycopg2

# Connect to Redis
cache = redis.StrictRedis(host='localhost', port=6379, db=0, decode_responses=True)

# Fetch product data with caching
def get_product_data(product_id):
    cache_key = f"product:{product_id}"
    
    product_data = cache.get(cache_key)
    if not product_data:
        conn = psycopg2.connect(dbname="bazaar_db", user="user", password="password", host="localhost")
        cursor = conn.cursor()
        cursor.execute("SELECT name, price FROM products WHERE id = %s", (product_id,))
        product_data = cursor.fetchone()
        conn.close()
        
        cache.set(cache_key, product_data)

    return product_data
